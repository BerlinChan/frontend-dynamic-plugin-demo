var pluginRoot = document.querySelector('.plugin-root');
var pluginElement = document.createElement('p')
pluginElement.innerHTML = "<p>插件 baz 内容</p>"
pluginRoot.appendChild(pluginElement)
